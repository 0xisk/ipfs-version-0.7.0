package node

import (
	"github.com/ipfs/go-ipfs/core"
)

func Mount(node *core.IpfsNode, fsdir, nsdir string) error {
	// TODO
	// currently a no-op, but we don't want to return an error
	return nil
}
