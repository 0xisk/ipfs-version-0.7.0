# this file defines several useful hashes used across the test codebase.
# thus they can be defined + changed in one place

HASH_WELCOME_DOCS="QmQPeNsJPyVWPFDVHb77w8G42Fvo15z4bG2X8D2GhfbSXc"
HASH_EMPTY_DIR="QmUNLLsPACCz1vLxQVkXqqLX5R1X345qqfHbsf67hvA3Nn"
