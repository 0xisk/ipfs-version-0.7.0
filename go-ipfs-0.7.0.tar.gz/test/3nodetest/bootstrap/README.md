this is a bootstrap peer with an empty bootstrap list

it listens on 4011 and 4012
