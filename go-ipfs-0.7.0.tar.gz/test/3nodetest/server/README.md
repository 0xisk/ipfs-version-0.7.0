**requirements**

* docker container with bootstrap node linked as "bootstrap" with ID QmNXuBh8HFsWq68Fid8dMbGNQTh7eG6hV9rr1fQyfmfomE
* file in data volume, internally mapped to /data/file
