---
name: 'Enhancement'
about: 'Suggest an improvement to an existing go-ipfs feature.'
labels: kind/enhancement
---

<!--
Note: If you'd like to suggest an idea related to IPFS but not specifically related to the Go implementation, please post in https://discuss.ipfs.io instead.

When requesting an _enhancement_, please be sure to include your motivation and try to be as specific as possible.
-->
